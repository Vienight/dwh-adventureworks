# Role Based Access Control

An implementation of [NIST level 2 RBAC](http://csrc.nist.gov/groups/SNS/rbac/)
Hierarchical RBAC

Work in progress, contributions welcome
